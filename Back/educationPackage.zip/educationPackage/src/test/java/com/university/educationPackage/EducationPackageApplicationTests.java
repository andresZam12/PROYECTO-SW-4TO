package com.university.educationPackage;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EducationPackageApplicationTests {

    @Test
    void contextLoads() {
        // Esta prueba verifica que el contexto de Spring Boot se cargue correctamente
    }

}
