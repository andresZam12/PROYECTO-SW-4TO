package com.university.educationPackage.exceptions;

public class AdmissionException extends RuntimeException {
    public AdmissionException(String message) {
        super(message);
    }
}